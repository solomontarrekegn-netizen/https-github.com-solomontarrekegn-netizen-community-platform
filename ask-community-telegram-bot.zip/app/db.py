import os
import sqlite3
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(os.getenv("DB_PATH", "community.db"))

@contextmanager
def connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()

def init_db():
    with connection() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER UNIQUE NOT NULL,
            username TEXT,
            display_name TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS questions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            category TEXT DEFAULT 'General',
            ai_answer TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS answers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(question_id) REFERENCES questions(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(question_id) REFERENCES questions(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS reactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            question_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            reaction TEXT NOT NULL CHECK(reaction IN ('up', 'down')),
            UNIQUE(question_id, user_id),
            FOREIGN KEY(question_id) REFERENCES questions(id),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """)

def upsert_user(telegram_id, username, display_name):
    with connection() as db:
        db.execute("""
            INSERT INTO users (telegram_id, username, display_name)
            VALUES (?, ?, ?)
            ON CONFLICT(telegram_id) DO UPDATE SET
                username=excluded.username,
                display_name=excluded.display_name
        """, (telegram_id, username, display_name))
        row = db.execute(
            "SELECT id FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return int(row["id"])

def create_question(user_id, text, category):
    with connection() as db:
        cur = db.execute(
            "INSERT INTO questions (user_id, text, category) VALUES (?, ?, ?)",
            (user_id, text, category)
        )
        return int(cur.lastrowid)

def set_ai_answer(question_id, answer):
    with connection() as db:
        db.execute(
            "UPDATE questions SET ai_answer=? WHERE id=?",
            (answer, question_id)
        )

def recent_questions(limit=8):
    with connection() as db:
        return db.execute("""
            SELECT q.id, q.text, q.category, q.created_at, u.display_name,
                   (SELECT COUNT(*) FROM answers a WHERE a.question_id=q.id) AS answer_count
            FROM questions q
            JOIN users u ON u.id=q.user_id
            ORDER BY q.id DESC
            LIMIT ?
        """, (limit,)).fetchall()

def get_question(question_id):
    with connection() as db:
        return db.execute("""
            SELECT q.*, u.display_name, u.telegram_id
            FROM questions q
            JOIN users u ON u.id=q.user_id
            WHERE q.id=?
        """, (question_id,)).fetchone()

def get_answers(question_id, limit=10):
    with connection() as db:
        return db.execute("""
            SELECT a.*, u.display_name
            FROM answers a
            JOIN users u ON u.id=a.user_id
            WHERE a.question_id=?
            ORDER BY a.id ASC LIMIT ?
        """, (question_id, limit)).fetchall()

def get_comments(question_id, limit=10):
    with connection() as db:
        return db.execute("""
            SELECT c.*, u.display_name
            FROM comments c
            JOIN users u ON u.id=c.user_id
            WHERE c.question_id=?
            ORDER BY c.id ASC LIMIT ?
        """, (question_id, limit)).fetchall()

def create_answer(question_id, user_id, text):
    with connection() as db:
        db.execute(
            "INSERT INTO answers (question_id, user_id, text) VALUES (?, ?, ?)",
            (question_id, user_id, text)
        )

def create_comment(question_id, user_id, text):
    with connection() as db:
        db.execute(
            "INSERT INTO comments (question_id, user_id, text) VALUES (?, ?, ?)",
            (question_id, user_id, text)
        )

def react(question_id, user_id, reaction):
    with connection() as db:
        existing = db.execute(
            "SELECT id, reaction FROM reactions WHERE question_id=? AND user_id=?",
            (question_id, user_id)
        ).fetchone()

        if existing and existing["reaction"] == reaction:
            db.execute("DELETE FROM reactions WHERE id=?", (existing["id"],))
        elif existing:
            db.execute(
                "UPDATE reactions SET reaction=? WHERE id=?",
                (reaction, existing["id"])
            )
        else:
            db.execute(
                "INSERT INTO reactions (question_id, user_id, reaction) VALUES (?, ?, ?)",
                (question_id, user_id, reaction)
            )

def reaction_counts(question_id):
    with connection() as db:
        row = db.execute("""
            SELECT
              SUM(CASE WHEN reaction='up' THEN 1 ELSE 0 END) AS ups,
              SUM(CASE WHEN reaction='down' THEN 1 ELSE 0 END) AS downs
            FROM reactions WHERE question_id=?
        """, (question_id,)).fetchone()
        return int(row["ups"] or 0), int(row["downs"] or 0)
