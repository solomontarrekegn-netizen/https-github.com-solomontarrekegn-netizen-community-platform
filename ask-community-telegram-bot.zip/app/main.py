import asyncio
import logging
import os

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from dotenv import load_dotenv

from .ai import generate_ai_answer
from .db import (
    create_answer, create_comment, create_question, get_answers, get_comments,
    get_question, init_db, reaction_counts, react, recent_questions,
    set_ai_answer, upsert_user
)

load_dotenv()
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

BOT_TOKEN = os.getenv("BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN is missing. Put it in .env")

bot = Bot(
    token=BOT_TOKEN,
    default=DefaultBotProperties(parse_mode=ParseMode.HTML)
)
dp = Dispatcher()

class AskState(StatesGroup):
    waiting_question = State()
    choosing_category = State()
    waiting_answer = State()
    waiting_comment = State()

def main_menu():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="❓ Ask a Question", callback_data="ask"),
            InlineKeyboardButton(text="📚 Browse", callback_data="browse")
        ],
        [
            InlineKeyboardButton(text="🔥 Recent", callback_data="browse"),
            InlineKeyboardButton(text="ℹ️ Help", callback_data="help")
        ]
    ])

def category_menu():
    categories = ["General", "Education", "Technology", "Business", "Relationships", "Ethiopia"]
    rows = []
    for i in range(0, len(categories), 2):
        row = [InlineKeyboardButton(text=categories[i], callback_data=f"cat:{categories[i]}")]
        if i + 1 < len(categories):
            row.append(InlineKeyboardButton(text=categories[i+1], callback_data=f"cat:{categories[i+1]}"))
        rows.append(row)
    return InlineKeyboardMarkup(inline_keyboard=rows)

def question_keyboard(question_id):
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="👍", callback_data=f"up:{question_id}"),
            InlineKeyboardButton(text="👎", callback_data=f"down:{question_id}"),
            InlineKeyboardButton(text="💬 Discuss", callback_data=f"discuss:{question_id}")
        ],
        [InlineKeyboardButton(text="✍️ Answer", callback_data=f"answer:{question_id}")],
        [InlineKeyboardButton(text="📖 Open Again", callback_data=f"view:{question_id}")]
    ])

def remember_user(message):
    user = message.from_user
    return upsert_user(
        user.id,
        user.username,
        user.full_name or user.username or "Anonymous"
    )

def format_question(row):
    ups, downs = reaction_counts(row["id"])
    text = (
        f"<b>❓ Question #{row['id']}</b>\n"
        f"<b>Category:</b> {row['category']}\n"
        f"<b>Asked by:</b> {row['display_name']}\n\n"
        f"{row['text']}\n\n"
        f"👍 {ups}   👎 {downs}"
    )
    if row["ai_answer"]:
        text += f"\n\n<b>🤖 AI answer</b>\n{row['ai_answer']}"
    return text

@dp.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    remember_user(message)
    await message.answer(
        "<b>Welcome to Ask Community.</b>\n\n"
        "Ask questions, answer people, and discuss ideas. "
        "AI can provide a first answer when enabled.",
        reply_markup=main_menu()
    )

@dp.message(Command("help"))
async def help_command(message: Message):
    await message.answer(
        "<b>How it works</b>\n\n"
        "❓ Ask a question\n"
        "🤖 Get an optional AI answer\n"
        "👥 Let people answer\n"
        "💬 Discuss the topic\n"
        "👍 React to questions"
    )

@dp.callback_query(F.data == "help")
async def help_callback(call: CallbackQuery):
    await call.answer()
    await call.message.edit_text(
        "<b>Ask Community</b>\n\n"
        "Questions belong to the community, not only to the AI. "
        "People can answer and discuss every question.",
        reply_markup=main_menu()
    )

@dp.callback_query(F.data == "ask")
async def ask_callback(call: CallbackQuery, state: FSMContext):
    await call.answer()
    await state.set_state(AskState.waiting_question)
    await call.message.answer(
        "<b>Ask your question</b>\n\n"
        "Write one clear question. You can use English, Amharic, or Oromo."
    )

@dp.message(AskState.waiting_question, F.text)
async def receive_question(message: Message, state: FSMContext):
    text = message.text.strip()
    if len(text) < 5:
        await message.answer("Please give a little more detail.")
        return
    await state.update_data(question_text=text)
    await state.set_state(AskState.choosing_category)
    await message.answer("<b>Choose a category:</b>", reply_markup=category_menu())

@dp.callback_query(AskState.choosing_category, F.data.startswith("cat:"))
async def choose_category(call: CallbackQuery, state: FSMContext):
    category = call.data.split(":", 1)[1]
    data = await state.get_data()
    user_id = upsert_user(
        call.from_user.id,
        call.from_user.username,
        call.from_user.full_name or call.from_user.username or "Anonymous"
    )
    question_id = create_question(user_id, data["question_text"], category)
    row = get_question(question_id)

    await call.answer("Question posted!")
    await call.message.edit_text(
        format_question(row) + "\n\n<i>Preparing an AI answer if AI is configured...</i>",
        reply_markup=question_keyboard(question_id)
    )

    ai_answer = await generate_ai_answer(data["question_text"])
    if ai_answer:
        set_ai_answer(question_id, ai_answer)
        row = get_question(question_id)
        try:
            await call.message.edit_text(
                format_question(row),
                reply_markup=question_keyboard(question_id)
            )
        except Exception:
            pass
    else:
        await call.message.answer("Your question is live. People can now answer and discuss it.")

    await state.clear()

@dp.callback_query(F.data == "browse")
async def browse_callback(call: CallbackQuery):
    await call.answer()
    rows = recent_questions()
    if not rows:
        await call.message.edit_text(
            "No questions yet. Be the first to ask one!",
            reply_markup=main_menu()
        )
        return

    buttons = [
        [InlineKeyboardButton(
            text=f"#{row['id']} • {row['text'][:45]}",
            callback_data=f"view:{row['id']}"
        )]
        for row in rows
    ]
    buttons.append([InlineKeyboardButton(text="❓ Ask a Question", callback_data="ask")])
    await call.message.edit_text(
        "<b>📚 Recent Questions</b>\n\nTap a question to open it.",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=buttons)
    )

@dp.callback_query(F.data.startswith("view:"))
async def view_question(call: CallbackQuery):
    question_id = int(call.data.split(":", 1)[1])
    row = get_question(question_id)
    if not row:
        await call.answer("Question not found.", show_alert=True)
        return

    await call.answer()
    text = format_question(row)
    answers = get_answers(question_id)
    comments = get_comments(question_id)

    if answers:
        text += "\n\n<b>👥 Community answers</b>"
        for answer in answers[:5]:
            text += f"\n\n<b>{answer['display_name']}:</b> {answer['text']}"

    if comments:
        text += "\n\n<b>💬 Discussion</b>"
        for comment in comments[:5]:
            text += f"\n\n<b>{comment['display_name']}:</b> {comment['text']}"

    await call.message.edit_text(text, reply_markup=question_keyboard(question_id))

@dp.callback_query(F.data.startswith("answer:"))
async def answer_callback(call: CallbackQuery, state: FSMContext):
    question_id = int(call.data.split(":", 1)[1])
    if not get_question(question_id):
        await call.answer("Question not found.", show_alert=True)
        return
    await call.answer()
    await state.update_data(question_id=question_id)
    await state.set_state(AskState.waiting_answer)
    await call.message.answer("✍️ Write your answer.")

@dp.message(AskState.waiting_answer, F.text)
async def receive_answer(message: Message, state: FSMContext):
    data = await state.get_data()
    question_id = data.get("question_id")
    if not question_id:
        await message.answer("Please choose a category using the buttons above.")
        return

    text = message.text.strip()
    if len(text) < 2:
        await message.answer("Please write a real answer.")
        return

    user_id = remember_user(message)
    create_answer(question_id, user_id, text)
    question = get_question(question_id)
    await state.clear()

    await message.answer(
        f"✅ Your answer was added to <b>Question #{question_id}</b>.",
        reply_markup=question_keyboard(question_id)
    )

    if question and question["telegram_id"] != message.from_user.id:
        try:
            await bot.send_message(
                question["telegram_id"],
                f"🔔 <b>Someone answered Question #{question_id}</b>\n\n{text}",
                reply_markup=question_keyboard(question_id)
            )
        except Exception:
            logger.info("Could not notify question owner.")

@dp.callback_query(F.data.startswith("discuss:"))
async def discuss_callback(call: CallbackQuery, state: FSMContext):
    question_id = int(call.data.split(":", 1)[1])
    if not get_question(question_id):
        await call.answer("Question not found.", show_alert=True)
        return
    await call.answer()
    await state.update_data(question_id=question_id)
    await state.set_state(AskState.waiting_comment)
    await call.message.answer("💬 Write your discussion point. Keep it respectful.")

@dp.message(AskState.waiting_comment, F.text)
async def receive_comment(message: Message, state: FSMContext):
    data = await state.get_data()
    question_id = data.get("question_id")
    if not question_id:
        await state.clear()
        await message.answer("Something went wrong. Open the question again.")
        return

    text = message.text.strip()
    if len(text) < 2:
        await message.answer("Please write a little more.")
        return

    user_id = remember_user(message)
    create_comment(question_id, user_id, text)
    await state.clear()
    await message.answer(
        f"💬 Discussion added to <b>Question #{question_id}</b>.",
        reply_markup=question_keyboard(question_id)
    )

@dp.callback_query(F.data.startswith(("up:", "down:")))
async def reaction_callback(call: CallbackQuery):
    kind, raw_id = call.data.split(":", 1)
    question_id = int(raw_id)
    user_id = upsert_user(
        call.from_user.id,
        call.from_user.username,
        call.from_user.full_name or call.from_user.username or "Anonymous"
    )
    react(question_id, user_id, "up" if kind == "up" else "down")
    ups, downs = reaction_counts(question_id)
    await call.answer(f"👍 {ups}  👎 {downs}")

async def main():
    init_db()
    logger.info("Ask Community Telegram bot starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
