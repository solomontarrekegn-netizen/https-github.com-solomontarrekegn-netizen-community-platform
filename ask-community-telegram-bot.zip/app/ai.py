import asyncio
import os

try:
    from google import genai
except ImportError:
    genai = None

async def generate_ai_answer(question):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key or genai is None:
        return None

    model = os.getenv("GEMINI_MODEL", "gemini-3.6-flash")
    prompt = f"""You are the AI assistant for Ask Community, a respectful community for learning and discussion.

Answer the user's question clearly and accurately. Keep the answer useful for a beginner when possible. Do not pretend to be a human community member.

Question:
{question}
"""

    def call():
        client = genai.Client(api_key=api_key)
        interaction = client.interactions.create(model=model, input=prompt)
        return interaction.output_text

    try:
        return await asyncio.to_thread(call)
    except Exception:
        return None
