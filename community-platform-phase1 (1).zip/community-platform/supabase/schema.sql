-- ============================================================
-- Commons — Phase 1 schema
-- Run this in the Supabase SQL editor (or via `supabase db push`).
-- Auth users live in the built-in `auth.users` table; everything
-- here references auth.users(id) instead of re-implementing auth.
-- ============================================================

create extension if not exists "pgcrypto";

-- ---------- profiles ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique not null check (char_length(username) between 3 and 20),
  display_name text,
  bio text,
  avatar_url text,
  created_at timestamptz not null default now()
);

-- ---------- categories ----------
create table if not exists public.categories (
  id serial primary key,
  name text unique not null,
  slug text unique not null,
  description text
);

-- ---------- questions ----------
create table if not exists public.questions (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 8 and 200),
  description text not null,
  category_id integer references public.categories(id) on delete set null,
  tags text[] not null default '{}',
  is_anonymous boolean not null default false,
  -- Phase 1 ships without live AI moderation, so questions default to
  -- 'approved'. The status column exists now so Phase 4's moderation
  -- pipeline (AI recommendation -> human review for medium/low confidence)
  -- can plug in without a schema migration.
  status text not null default 'approved'
    check (status in ('approved', 'needs_edit', 'rejected', 'human_review')),
  answer_count integer not null default 0,
  vote_count integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists questions_status_created_idx
  on public.questions (status, created_at desc);
create index if not exists questions_category_idx on public.questions (category_id);
create index if not exists questions_author_idx on public.questions (author_id);
create index if not exists questions_tags_idx on public.questions using gin (tags);

-- ---------- answers ----------
create table if not exists public.answers (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) > 0),
  is_anonymous boolean not null default false,
  vote_count integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists answers_question_idx on public.answers (question_id);

-- ---------- replies ----------
create table if not exists public.replies (
  id uuid primary key default gen_random_uuid(),
  answer_id uuid not null references public.answers(id) on delete cascade,
  author_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(body) > 0),
  is_anonymous boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists replies_answer_idx on public.replies (answer_id);

-- ---------- votes ----------
-- One row per (user, content). content_type distinguishes questions vs answers
-- so both can share a single votes table, matching the Phase 1 schema sketch.
create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  content_id uuid not null,
  content_type text not null check (content_type in ('question', 'answer')),
  vote_type smallint not null check (vote_type in (1, -1)),
  created_at timestamptz not null default now(),
  unique (user_id, content_id, content_type)
);

-- ============================================================
-- Triggers: keep answer_count / vote_count denormalized and in sync
-- ============================================================

create or replace function public.handle_new_answer()
returns trigger language plpgsql as $$
begin
  update public.questions set answer_count = answer_count + 1 where id = new.question_id;
  return new;
end;
$$;

drop trigger if exists on_answer_insert on public.answers;
create trigger on_answer_insert
  after insert on public.answers
  for each row execute function public.handle_new_answer();

create or replace function public.handle_answer_delete()
returns trigger language plpgsql as $$
begin
  update public.questions set answer_count = greatest(answer_count - 1, 0) where id = old.question_id;
  return old;
end;
$$;

drop trigger if exists on_answer_delete on public.answers;
create trigger on_answer_delete
  after delete on public.answers
  for each row execute function public.handle_answer_delete();

create or replace function public.handle_vote_change()
returns trigger language plpgsql as $$
declare
  target_id uuid;
  target_type text;
  delta integer;
begin
  if tg_op = 'DELETE' then
    target_id := old.content_id;
    target_type := old.content_type;
    delta := -old.vote_type;
  elsif tg_op = 'INSERT' then
    target_id := new.content_id;
    target_type := new.content_type;
    delta := new.vote_type;
  else -- UPDATE (user flips their vote)
    target_id := new.content_id;
    target_type := new.content_type;
    delta := new.vote_type - old.vote_type;
  end if;

  if target_type = 'question' then
    update public.questions set vote_count = vote_count + delta where id = target_id;
  else
    update public.answers set vote_count = vote_count + delta where id = target_id;
  end if;

  return coalesce(new, old);
end;
$$;

drop trigger if exists on_vote_change on public.votes;
create trigger on_vote_change
  after insert or update or delete on public.votes
  for each row execute function public.handle_vote_change();

-- ============================================================
-- Row Level Security
-- ============================================================

alter table public.profiles enable row level security;
alter table public.categories enable row level security;
alter table public.questions enable row level security;
alter table public.answers enable row level security;
alter table public.replies enable row level security;
alter table public.votes enable row level security;

-- profiles: publicly readable, only the owner can insert/update their own row
create policy "profiles are publicly readable" on public.profiles
  for select using (true);
create policy "users can insert their own profile" on public.profiles
  for insert with check (auth.uid() = id);
create policy "users can update their own profile" on public.profiles
  for update using (auth.uid() = id);

-- categories: publicly readable, no client writes (managed by admins)
create policy "categories are publicly readable" on public.categories
  for select using (true);

-- questions: approved questions are public; authors can also see their own
-- non-approved ones (needs_edit / rejected / human_review) so they get
-- feedback. Any authenticated user can post; only the author can edit/delete.
create policy "approved questions are publicly readable" on public.questions
  for select using (status = 'approved' or auth.uid() = author_id);
create policy "authenticated users can post questions" on public.questions
  for insert with check (auth.uid() = author_id);
create policy "authors can update their own questions" on public.questions
  for update using (auth.uid() = author_id);
create policy "authors can delete their own questions" on public.questions
  for delete using (auth.uid() = author_id);

-- answers: publicly readable, authenticated users can post, authors can edit/delete their own
create policy "answers are publicly readable" on public.answers
  for select using (true);
create policy "authenticated users can post answers" on public.answers
  for insert with check (auth.uid() = author_id);
create policy "authors can update their own answers" on public.answers
  for update using (auth.uid() = author_id);
create policy "authors can delete their own answers" on public.answers
  for delete using (auth.uid() = author_id);

-- replies: same shape as answers
create policy "replies are publicly readable" on public.replies
  for select using (true);
create policy "authenticated users can post replies" on public.replies
  for insert with check (auth.uid() = author_id);
create policy "authors can update their own replies" on public.replies
  for update using (auth.uid() = author_id);
create policy "authors can delete their own replies" on public.replies
  for delete using (auth.uid() = author_id);

-- votes: users can only see and manage their own vote rows;
-- vote_count on questions/answers is public via those tables' own policies.
create policy "users can read their own votes" on public.votes
  for select using (auth.uid() = user_id);
create policy "users can cast votes" on public.votes
  for insert with check (auth.uid() = user_id);
create policy "users can change their own votes" on public.votes
  for update using (auth.uid() = user_id);
create policy "users can remove their own votes" on public.votes
  for delete using (auth.uid() = user_id);

-- ============================================================
-- Seed categories (matches the examples in the product brief)
-- ============================================================

insert into public.categories (name, slug, description) values
  ('Education', 'education', 'Learning paths, courses, scholarships, study groups'),
  ('Technology', 'technology', 'Software, AI, engineering, tools'),
  ('Business', 'business', 'Startups, partnerships, entrepreneurship'),
  ('Politics', 'politics', 'Policy and public affairs discussion'),
  ('Career', 'career', 'Jobs, internships, career advice'),
  ('Science', 'science', 'Research, discoveries, how things work'),
  ('Health', 'health', 'Wellbeing, fitness, healthcare'),
  ('Ethiopia', 'ethiopia', 'Topics specific to Ethiopia'),
  ('General Knowledge', 'general-knowledge', 'Anything that does not fit elsewhere')
on conflict (slug) do nothing;
