/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#22252B',
        paper: '#F7F5F1',
        indigo: {
          DEFAULT: '#1B2A4A',
          light: '#2C4270',
          dark: '#101A30',
        },
        gold: {
          DEFAULT: '#C89B3C',
          light: '#E0BE6C',
          dark: '#9C7726',
        },
        sage: {
          DEFAULT: '#6B8F71',
          light: '#8FAE94',
        },
        line: '#E4E0D6',
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        body: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      borderRadius: {
        sm: '4px',
        md: '8px',
      },
    },
  },
  plugins: [],
}
