import { useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'

export default function Signup() {
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const navigate = useNavigate()

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    setError(null)

    if (!/^[a-z0-9_]{3,20}$/i.test(username)) {
      setError('Username must be 3-20 characters: letters, numbers, underscores.')
      return
    }

    setBusy(true)

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
    })

    if (signUpError || !data.user) {
      setBusy(false)
      setError(signUpError?.message ?? 'Could not create account.')
      return
    }

    // Profile row: relies on RLS policy allowing a user to insert their own profile.
    const { error: profileError } = await supabase.from('profiles').insert({
      id: data.user.id,
      username,
      display_name: username,
    })

    setBusy(false)

    if (profileError) {
      setError(
        profileError.message.includes('duplicate')
          ? 'That username is taken.'
          : profileError.message
      )
      return
    }

    navigate('/')
  }

  return (
    <div className="mx-auto max-w-sm px-4 py-16">
      <h1 className="mb-2 font-display text-2xl font-semibold text-indigo">Join Commons</h1>
      <p className="mb-6 text-sm text-ink/60">
        Ask questions, find people, and discover opportunities.
      </p>
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <label className="text-sm font-medium">
          Username
          <input
            required
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        <label className="text-sm font-medium">
          Email
          <input
            type="email"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        <label className="text-sm font-medium">
          Password
          <input
            type="password"
            required
            minLength={6}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        {error && <p className="text-sm text-red-600">{error}</p>}
        <button
          disabled={busy}
          className="rounded-md bg-indigo px-4 py-2 font-medium text-paper hover:bg-indigo-light disabled:opacity-50"
        >
          {busy ? 'Creating account…' : 'Create account'}
        </button>
      </form>
      <p className="mt-4 text-sm text-ink/60">
        Already have an account?{' '}
        <Link to="/login" className="font-medium text-indigo hover:underline">
          Log in
        </Link>
      </p>
    </div>
  )
}
