import { useEffect, useState, FormEvent } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import { Question, Answer, Reply } from '../types'
import CategoryChip from '../components/CategoryChip'
import VoteButton from '../components/VoteButton'

function AnswerReplies({ answerId }: { answerId: string }) {
  const { user } = useAuth()
  const [replies, setReplies] = useState<Reply[]>([])
  const [body, setBody] = useState('')
  const [open, setOpen] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    supabase
      .from('replies')
      .select('*, author:profiles(*)')
      .eq('answer_id', answerId)
      .order('created_at', { ascending: true })
      .then(({ data }) => setReplies((data as Reply[]) ?? []))
  }, [answerId])

  async function submitReply(e: FormEvent) {
    e.preventDefault()
    if (!user || !body.trim()) return
    setBusy(true)
    const { data, error } = await supabase
      .from('replies')
      .insert({ answer_id: answerId, author_id: user.id, body: body.trim() })
      .select('*, author:profiles(*)')
      .single()
    setBusy(false)
    if (!error && data) {
      setReplies((r) => [...r, data as Reply])
      setBody('')
    }
  }

  return (
    <div className="ml-6 mt-2 border-l border-line pl-4">
      {replies.map((r) => (
        <div key={r.id} className="mb-2 text-sm">
          <span className="font-medium text-indigo">
            {r.is_anonymous ? 'Anonymous' : r.author?.username ?? 'Unknown'}
          </span>{' '}
          <span className="text-ink/80">{r.body}</span>
        </div>
      ))}

      {user &&
        (open ? (
          <form onSubmit={submitReply} className="mt-2 flex gap-2">
            <input
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Write a reply…"
              className="flex-1 rounded-md border border-line bg-white px-2 py-1 text-sm outline-none focus:border-indigo"
            />
            <button
              disabled={busy}
              className="rounded-md bg-indigo px-3 py-1 text-sm text-paper hover:bg-indigo-light disabled:opacity-50"
            >
              Reply
            </button>
          </form>
        ) : (
          <button onClick={() => setOpen(true)} className="mt-1 text-xs text-ink/50 hover:text-indigo">
            Reply
          </button>
        ))}
    </div>
  )
}

export default function QuestionDetail() {
  const { id } = useParams()
  const { user } = useAuth()
  const [question, setQuestion] = useState<Question | null>(null)
  const [answers, setAnswers] = useState<Answer[]>([])
  const [answerBody, setAnswerBody] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  async function loadAnswers() {
    const { data } = await supabase
      .from('answers')
      .select('*, author:profiles(*)')
      .eq('question_id', id)
      .order('vote_count', { ascending: false })
    setAnswers((data as Answer[]) ?? [])
  }

  useEffect(() => {
    if (!id) return

    supabase
      .from('questions')
      .select('*, author:profiles(*), category:categories(*)')
      .eq('id', id)
      .single()
      .then(({ data }) => setQuestion(data as Question))

    loadAnswers()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id])

  async function submitAnswer(e: FormEvent) {
    e.preventDefault()
    if (!user || !id || !answerBody.trim()) return
    setBusy(true)
    setError(null)

    const { error: insertError } = await supabase.from('answers').insert({
      question_id: id,
      author_id: user.id,
      body: answerBody.trim(),
    })

    setBusy(false)

    if (insertError) {
      setError(insertError.message)
      return
    }

    setAnswerBody('')
    loadAnswers()
  }

  if (!question) return <div className="p-8 text-center text-ink/50">Loading…</div>

  const authorLabel = question.is_anonymous ? 'Anonymous' : question.author?.username ?? 'Unknown'

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <div className="flex items-center gap-2 text-xs text-ink/50">
        {question.category && <CategoryChip name={question.category.name} />}
        <span>{authorLabel}</span>
        <span>·</span>
        <span>{new Date(question.created_at).toLocaleDateString()}</span>
      </div>

      <h1 className="mt-2 font-display text-2xl font-semibold leading-snug text-ink">
        {question.title}
      </h1>

      <p className="mt-3 whitespace-pre-wrap text-ink/80">{question.description}</p>

      <div className="mt-4 flex items-center gap-4">
        <VoteButton
          contentId={question.id}
          contentType="question"
          voteCount={question.vote_count}
        />
        <div className="flex gap-2">
          {question.tags?.map((t) => (
            <span key={t} className="font-mono text-xs text-gold-dark">
              #{t}
            </span>
          ))}
        </div>
      </div>

      <hr className="my-8 border-line" />

      <h2 className="mb-4 font-display text-lg font-semibold text-indigo">
        {answers.length} {answers.length === 1 ? 'Answer' : 'Answers'}
      </h2>

      <div className="flex flex-col gap-6">
        {answers.map((a) => (
          <div key={a.id} className="rounded-md border border-line bg-white p-4">
            <div className="flex gap-4">
              <VoteButton contentId={a.id} contentType="answer" voteCount={a.vote_count} />
              <div className="flex-1">
                <p className="whitespace-pre-wrap text-sm text-ink/90">{a.body}</p>
                <div className="mt-2 text-xs text-ink/50">
                  {a.is_anonymous ? 'Anonymous' : a.author?.username ?? 'Unknown'} ·{' '}
                  {new Date(a.created_at).toLocaleDateString()}
                </div>
                <AnswerReplies answerId={a.id} />
              </div>
            </div>
          </div>
        ))}
      </div>

      {user ? (
        <form onSubmit={submitAnswer} className="mt-8 flex flex-col gap-3">
          <label className="text-sm font-medium">
            Your answer
            <textarea
              required
              rows={4}
              value={answerBody}
              onChange={(e) => setAnswerBody(e.target.value)}
              className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
            />
          </label>
          {error && <p className="text-sm text-red-600">{error}</p>}
          <button
            disabled={busy}
            className="self-start rounded-md bg-indigo px-5 py-2 font-medium text-paper hover:bg-indigo-light disabled:opacity-50"
          >
            {busy ? 'Posting…' : 'Post answer'}
          </button>
        </form>
      ) : (
        <p className="mt-8 text-sm text-ink/50">Log in to answer this question.</p>
      )}
    </div>
  )
}
