import { useState, FormEvent } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'

export default function Profile() {
  const { profile, refreshProfile } = useAuth()
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '')
  const [bio, setBio] = useState(profile?.bio ?? '')
  const [busy, setBusy] = useState(false)
  const [saved, setSaved] = useState(false)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!profile) return
    setBusy(true)
    setSaved(false)
    await supabase
      .from('profiles')
      .update({ display_name: displayName, bio })
      .eq('id', profile.id)
    await refreshProfile()
    setBusy(false)
    setSaved(true)
  }

  if (!profile) return <div className="p-8 text-center text-ink/50">Loading…</div>

  return (
    <div className="mx-auto max-w-lg px-4 py-10">
      <h1 className="mb-1 font-display text-2xl font-semibold text-indigo">@{profile.username}</h1>
      <p className="mb-6 text-sm text-ink/50">Member since {new Date(profile.created_at).toLocaleDateString()}</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <label className="text-sm font-medium">
          Display name
          <input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        <label className="text-sm font-medium">
          Bio
          <textarea
            rows={4}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            placeholder="Interests, skills, what you're looking for…"
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        <button
          disabled={busy}
          className="self-start rounded-md bg-indigo px-5 py-2 font-medium text-paper hover:bg-indigo-light disabled:opacity-50"
        >
          {busy ? 'Saving…' : 'Save profile'}
        </button>
        {saved && <p className="text-sm text-sage">Saved.</p>}
      </form>
    </div>
  )
}
