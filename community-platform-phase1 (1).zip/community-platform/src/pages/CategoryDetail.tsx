import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { Question, Category } from '../types'
import QuestionCard from '../components/QuestionCard'

export default function CategoryDetail() {
  const { slug } = useParams()
  const [category, setCategory] = useState<Category | null>(null)
  const [questions, setQuestions] = useState<Question[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!slug) return

    async function load() {
      const { data: cat } = await supabase
        .from('categories')
        .select('*')
        .eq('slug', slug)
        .single()

      setCategory(cat as Category)

      if (cat) {
        const { data: qs } = await supabase
          .from('questions')
          .select('*, author:profiles(*), category:categories(*)')
          .eq('category_id', (cat as Category).id)
          .eq('status', 'approved')
          .order('created_at', { ascending: false })
        setQuestions((qs as Question[]) ?? [])
      }
      setLoading(false)
    }

    load()
  }, [slug])

  if (loading) return <div className="p-8 text-center text-ink/50">Loading…</div>
  if (!category) return <div className="p-8 text-center text-ink/50">Category not found.</div>

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="font-display text-2xl font-semibold text-indigo">{category.name}</h1>
      {category.description && <p className="mt-1 text-ink/60">{category.description}</p>}

      <div className="mt-6 flex flex-col gap-3">
        {questions.length === 0 && (
          <p className="text-ink/50">No questions in this category yet.</p>
        )}
        {questions.map((q) => (
          <QuestionCard key={q.id} question={q} />
        ))}
      </div>
    </div>
  )
}
