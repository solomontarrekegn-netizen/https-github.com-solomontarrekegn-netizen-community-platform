import { useEffect, useState, FormEvent } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import { Category } from '../types'

export default function AskQuestion() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [categories, setCategories] = useState<Category[]>([])
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [categoryId, setCategoryId] = useState<number | ''>('')
  const [tagsInput, setTagsInput] = useState('')
  const [isAnonymous, setIsAnonymous] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    supabase
      .from('categories')
      .select('*')
      .order('name')
      .then(({ data }) => setCategories((data as Category[]) ?? []))
  }, [])

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!user) return
    setError(null)

    if (title.trim().length < 8) {
      setError('Give your question a bit more detail in the title (at least 8 characters).')
      return
    }

    setBusy(true)

    const tags = tagsInput
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean)
      .slice(0, 5)

    const { data, error: insertError } = await supabase
      .from('questions')
      .insert({
        author_id: user.id,
        title: title.trim(),
        description: description.trim(),
        category_id: categoryId || null,
        tags,
        is_anonymous: isAnonymous,
        // Phase 1: no live AI moderation yet, questions publish directly.
        // The `status` column exists so Phase 4 can plug in AI moderation
        // (approved / needs_edit / rejected / human_review) without a schema change.
        status: 'approved',
      })
      .select()
      .single()

    setBusy(false)

    if (insertError) {
      setError(insertError.message)
      return
    }

    navigate(`/question/${data.id}`)
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <h1 className="mb-6 font-display text-2xl font-semibold text-indigo">Ask a question</h1>
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        <label className="text-sm font-medium">
          Title
          <input
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="What is the best path to learn machine learning?"
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          Details
          <textarea
            required
            rows={6}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Add context so the community can give you a useful answer."
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <div className="grid grid-cols-2 gap-4">
          <label className="text-sm font-medium">
            Category
            <select
              value={categoryId}
              onChange={(e) => setCategoryId(e.target.value ? Number(e.target.value) : '')}
              className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
            >
              <option value="">Uncategorized</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>

          <label className="text-sm font-medium">
            Tags (comma separated)
            <input
              value={tagsInput}
              onChange={(e) => setTagsInput(e.target.value)}
              placeholder="ai, education"
              className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
            />
          </label>
        </div>

        <label className="flex items-center gap-2 text-sm">
          <input
            type="checkbox"
            checked={isAnonymous}
            onChange={(e) => setIsAnonymous(e.target.checked)}
          />
          Post anonymously (your username won't be shown publicly)
        </label>

        {error && <p className="text-sm text-red-600">{error}</p>}

        <button
          disabled={busy}
          className="self-start rounded-md bg-indigo px-5 py-2 font-medium text-paper hover:bg-indigo-light disabled:opacity-50"
        >
          {busy ? 'Posting…' : 'Post question'}
        </button>
      </form>
    </div>
  )
}
