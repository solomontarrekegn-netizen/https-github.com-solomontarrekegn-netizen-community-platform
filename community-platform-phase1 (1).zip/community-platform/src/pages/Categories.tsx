import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { Category } from '../types'

export default function Categories() {
  const [categories, setCategories] = useState<Category[]>([])

  useEffect(() => {
    supabase
      .from('categories')
      .select('*')
      .order('name')
      .then(({ data }) => setCategories((data as Category[]) ?? []))
  }, [])

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-6 font-display text-2xl font-semibold text-indigo">Categories</h1>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {categories.map((c) => (
          <Link
            key={c.id}
            to={`/category/${c.slug}`}
            className="rounded-md border border-line bg-white p-4 hover:border-indigo/40"
          >
            <div className="font-display font-semibold text-ink">{c.name}</div>
            {c.description && <div className="mt-1 text-xs text-ink/50">{c.description}</div>}
          </Link>
        ))}
      </div>
    </div>
  )
}
