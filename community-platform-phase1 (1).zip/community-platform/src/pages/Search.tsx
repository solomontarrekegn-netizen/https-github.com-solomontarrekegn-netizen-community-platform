import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { Question } from '../types'
import QuestionCard from '../components/QuestionCard'

export default function Search() {
  const [params] = useSearchParams()
  const q = params.get('q') ?? ''
  const [results, setResults] = useState<Question[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!q) {
      setResults([])
      return
    }
    setLoading(true)
    supabase
      .from('questions')
      .select('*, author:profiles(*), category:categories(*)')
      .eq('status', 'approved')
      .or(`title.ilike.%${q}%,description.ilike.%${q}%`)
      .order('created_at', { ascending: false })
      .limit(30)
      .then(({ data }) => {
        setResults((data as Question[]) ?? [])
        setLoading(false)
      })
  }, [q])

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-6 font-display text-2xl font-semibold text-indigo">
        {q ? `Results for "${q}"` : 'Search'}
      </h1>

      {loading && <p className="text-ink/50">Searching…</p>}
      {!loading && q && results.length === 0 && (
        <p className="text-ink/50">No questions matched. Try a different search.</p>
      )}

      <div className="flex flex-col gap-3">
        {results.map((r) => (
          <QuestionCard key={r.id} question={r} />
        ))}
      </div>
    </div>
  )
}
