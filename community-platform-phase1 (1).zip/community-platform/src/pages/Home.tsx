import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { Question, Category } from '../types'
import QuestionCard from '../components/QuestionCard'
import CategoryChip from '../components/CategoryChip'

export default function Home() {
  const [questions, setQuestions] = useState<Question[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let active = true

    async function load() {
      setLoading(true)
      const [{ data: qData, error: qError }, { data: cData }] = await Promise.all([
        supabase
          .from('questions')
          .select('*, author:profiles(*), category:categories(*)')
          .eq('status', 'approved')
          .order('created_at', { ascending: false })
          .limit(20),
        supabase.from('categories').select('*').order('name'),
      ])

      if (!active) return
      if (qError) setError(qError.message)
      setQuestions((qData as Question[]) ?? [])
      setCategories((cData as Category[]) ?? [])
      setLoading(false)
    }

    load()
    return () => {
      active = false
    }
  }, [])

  return (
    <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 px-4 py-8 md:grid-cols-[1fr_220px]">
      <div>
        <div className="mb-6 flex items-center justify-between">
          <h1 className="font-display text-2xl font-semibold text-indigo">Community feed</h1>
          <Link
            to="/ask"
            className="rounded-md bg-indigo px-4 py-2 text-sm font-medium text-paper hover:bg-indigo-light"
          >
            Ask a question
          </Link>
        </div>

        {loading && <p className="text-ink/50">Loading questions…</p>}
        {error && <p className="text-red-600">{error}</p>}
        {!loading && questions.length === 0 && (
          <div className="rounded-md border border-dashed border-line p-8 text-center text-ink/50">
            No questions yet. Be the first to ask something.
          </div>
        )}

        <div className="flex flex-col gap-3">
          {questions.map((q) => (
            <QuestionCard key={q.id} question={q} />
          ))}
        </div>
      </div>

      <aside>
        <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ink/50">
          Categories
        </h2>
        <div className="flex flex-wrap gap-2">
          {categories.map((c) => (
            <CategoryChip key={c.id} name={c.name} slug={c.slug} />
          ))}
        </div>
      </aside>
    </div>
  )
}
