import { Link, useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { useAuth } from '../context/AuthContext'

export default function Navbar() {
  const { user, profile, signOut } = useAuth()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')

  function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`)
  }

  return (
    <header className="sticky top-0 z-10 border-b border-line bg-paper/95 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center gap-4 px-4 py-3">
        <Link to="/" className="font-display text-xl font-semibold text-indigo shrink-0">
          Commons
        </Link>

        <form onSubmit={handleSearch} className="flex-1 max-w-md">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions, people, topics"
            className="w-full rounded-md border border-line bg-white px-3 py-1.5 text-sm outline-none focus:border-indigo"
          />
        </form>

        <nav className="ml-auto hidden items-center gap-5 text-sm font-medium text-ink/80 sm:flex">
          <Link to="/" className="hover:text-indigo">
            Home
          </Link>
          <Link to="/categories" className="hover:text-indigo">
            Categories
          </Link>
          {user && (
            <Link to="/ask" className="rounded-md bg-indigo px-3 py-1.5 text-paper hover:bg-indigo-light">
              Ask
            </Link>
          )}
        </nav>

        {user ? (
          <div className="flex items-center gap-3">
            <Link to="/profile" className="text-sm font-medium text-ink/80 hover:text-indigo">
              {profile?.username ?? 'Profile'}
            </Link>
            <button
              onClick={() => signOut()}
              className="text-sm text-ink/50 hover:text-ink"
            >
              Sign out
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium hover:text-indigo">
              Log in
            </Link>
            <Link
              to="/signup"
              className="rounded-md bg-indigo px-3 py-1.5 text-sm font-medium text-paper hover:bg-indigo-light"
            >
              Join
            </Link>
          </div>
        )}
      </div>
    </header>
  )
}
