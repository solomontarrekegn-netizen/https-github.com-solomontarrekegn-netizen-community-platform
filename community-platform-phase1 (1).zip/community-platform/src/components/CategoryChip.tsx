import { Link } from 'react-router-dom'

export default function CategoryChip({ name, slug }: { name: string; slug?: string }) {
  const content = (
    <span className="inline-flex items-center rounded-sm border border-line bg-white px-2 py-0.5 font-mono text-xs uppercase tracking-wide text-indigo/80">
      {name}
    </span>
  )
  if (!slug) return content
  return (
    <Link to={`/category/${slug}`} className="hover:opacity-80">
      {content}
    </Link>
  )
}
