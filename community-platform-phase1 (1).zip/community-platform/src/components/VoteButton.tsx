import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'

type ContentType = 'question' | 'answer'

export default function VoteButton({
  contentId,
  contentType,
  voteCount,
  onChange,
}: {
  contentId: string
  contentType: ContentType
  voteCount: number
  onChange?: (newCount: number) => void
}) {
  const { user } = useAuth()
  const [myVote, setMyVote] = useState<number>(0)
  const [count, setCount] = useState(voteCount)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    setCount(voteCount)
  }, [voteCount])

  useEffect(() => {
    if (!user) return
    supabase
      .from('votes')
      .select('vote_type')
      .eq('user_id', user.id)
      .eq('content_id', contentId)
      .eq('content_type', contentType)
      .maybeSingle()
      .then(({ data }) => setMyVote(data?.vote_type ?? 0))
  }, [user, contentId, contentType])

  async function vote(direction: 1 | -1) {
    if (!user || busy) return
    setBusy(true)
    const nextVote = myVote === direction ? 0 : direction
    const delta = nextVote - myVote

    if (nextVote === 0) {
      await supabase
        .from('votes')
        .delete()
        .eq('user_id', user.id)
        .eq('content_id', contentId)
        .eq('content_type', contentType)
    } else {
      await supabase.from('votes').upsert(
        {
          user_id: user.id,
          content_id: contentId,
          content_type: contentType,
          vote_type: nextVote,
        },
        { onConflict: 'user_id,content_id,content_type' }
      )
    }

    const newCount = count + delta
    setMyVote(nextVote)
    setCount(newCount)
    onChange?.(newCount)
    setBusy(false)
  }

  return (
    <div className="flex items-center gap-1 text-ink/70">
      <button
        disabled={!user || busy}
        onClick={() => vote(1)}
        aria-label="Upvote"
        className={`rounded-sm border border-line px-2 py-1 text-sm hover:border-indigo disabled:opacity-40 ${
          myVote === 1 ? 'bg-indigo text-paper border-indigo' : 'bg-white'
        }`}
      >
        ▲
      </button>
      <span className="min-w-[2ch] text-center font-mono text-sm">{count}</span>
      <button
        disabled={!user || busy}
        onClick={() => vote(-1)}
        aria-label="Downvote"
        className={`rounded-sm border border-line px-2 py-1 text-sm hover:border-indigo disabled:opacity-40 ${
          myVote === -1 ? 'bg-indigo text-paper border-indigo' : 'bg-white'
        }`}
      >
        ▼
      </button>
    </div>
  )
}
