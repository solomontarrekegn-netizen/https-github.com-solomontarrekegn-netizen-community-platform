import { Link } from 'react-router-dom'
import { Question } from '../types'
import CategoryChip from './CategoryChip'

function timeAgo(iso: string) {
  const diffMs = Date.now() - new Date(iso).getTime()
  const mins = Math.floor(diffMs / 60000)
  if (mins < 1) return 'just now'
  if (mins < 60) return `${mins}m ago`
  const hours = Math.floor(mins / 60)
  if (hours < 24) return `${hours}h ago`
  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}d ago`
  return new Date(iso).toLocaleDateString()
}

export default function QuestionCard({ question }: { question: Question }) {
  const authorLabel = question.is_anonymous ? 'Anonymous' : question.author?.username ?? 'Unknown'

  return (
    <Link
      to={`/question/${question.id}`}
      className="block rounded-md border border-line bg-white p-4 transition-colors hover:border-indigo/40"
    >
      <div className="flex items-center gap-2 text-xs text-ink/50">
        {question.category && <CategoryChip name={question.category.name} />}
        <span>{authorLabel}</span>
        <span>·</span>
        <span>{timeAgo(question.created_at)}</span>
      </div>

      <h3 className="mt-2 font-display text-lg font-semibold leading-snug text-ink">
        {question.title}
      </h3>

      <p className="mt-1 line-clamp-2 text-sm text-ink/70">{question.description}</p>

      <div className="mt-3 flex items-center gap-4 text-xs font-medium text-ink/60">
        <span>{question.answer_count} answers</span>
        <span>{question.vote_count} upvotes</span>
        {question.tags?.slice(0, 3).map((t) => (
          <span key={t} className="text-gold-dark">
            #{t}
          </span>
        ))}
      </div>
    </Link>
  )
}
