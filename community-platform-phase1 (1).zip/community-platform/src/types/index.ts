export type Profile = {
  id: string
  username: string
  display_name: string | null
  bio: string | null
  avatar_url: string | null
  created_at: string
}

export type Category = {
  id: number
  name: string
  slug: string
  description: string | null
}

export type QuestionStatus = 'approved' | 'needs_edit' | 'rejected' | 'human_review'

export type Question = {
  id: string
  author_id: string
  title: string
  description: string
  category_id: number | null
  tags: string[]
  is_anonymous: boolean
  status: QuestionStatus
  answer_count: number
  vote_count: number
  created_at: string
  // Joined fields (populated client-side)
  author?: Profile | null
  category?: Category | null
}

export type Answer = {
  id: string
  question_id: string
  author_id: string
  body: string
  is_anonymous: boolean
  vote_count: number
  created_at: string
  author?: Profile | null
}

export type Reply = {
  id: string
  answer_id: string
  author_id: string
  body: string
  is_anonymous: boolean
  created_at: string
  author?: Profile | null
}
