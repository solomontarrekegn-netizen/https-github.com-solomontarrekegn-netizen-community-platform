# Commons — Phase 1 + 2

A community Q&A and people-discovery platform. This covers **Phase 1**
(questions/answers/replies/categories/search) and **Phase 2** (rich profiles,
people discovery, following, notifications, reputation) of the larger
product vision. "Commons" is a placeholder name — rename it freely, including
in `index.html` and `Navbar.tsx`.

**What's real:** authentication, profiles (skills, interests, goals,
education, profession, languages, location, "looking for"), posting
questions (categories, tags, anonymous option), answering, threaded replies,
upvote/downvote, category browsing, text search, following/unfollowing
people, a notifications inbox (new answer / new reply / new follower), and a
reputation score driven by real votes on your content. All of it is backed
by a real Supabase Postgres database with Row Level Security — none of it is
hard-coded demo data.

**What's intentionally not built yet:** AI moderation, business
partner/opportunity matching, jobs/education opportunity boards, the
Telegram Mini App wrapper, and badge tiers beyond the two simple
reputation-based ones in `src/lib/reputation.ts`. The `questions.status`
column and the phased plan below are designed so those slot in without
reshaping the schema.

## 1. Prerequisites

- Node.js 18+
- A free [Supabase](https://supabase.com) project

## 2. Set up Supabase

1. Create a new project at supabase.com.
2. Open the **SQL Editor** and run the contents of `supabase/schema.sql`.
   This creates the Phase 1 tables, triggers (for denormalized vote/answer
   counts), Row Level Security policies, and seeds the starter categories.
3. Run `supabase/phase2.sql` next, in the same SQL editor. It adds the
   extended profile columns, `follows`, `notifications`, and the reputation
   trigger — additive only, safe to run after schema.sql on an existing
   database.
4. Go to **Project Settings → API** and copy your **Project URL** and
   **anon public key**.

## 3. Configure the app

```bash
cp .env.example .env
# then edit .env and paste your Supabase URL + anon key
```

## 4. Install and run locally

```bash
npm install
npm run dev
```

Visit `http://localhost:5173`. Sign up for an account (Supabase's default
email confirmation may be on — you can turn it off under **Authentication →
Providers → Email** while developing), then ask a question.

## 5. Build for production

```bash
npm run build
```

Output goes to `dist/`.

## 6. Deploy to Netlify

1. Push this project to a Git repo (GitHub/GitLab/Bitbucket).
2. In Netlify: **Add new site → Import an existing project**, pick the repo.
3. Build command: `npm run build`. Publish directory: `dist`.
4. Under **Site settings → Environment variables**, add:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. Because this is a client-side router (React Router), add a redirect so
   deep links like `/question/abc` don't 404. Create `public/_redirects`
   with:
   ```
   /*  /index.html  200
   ```
   (Vite copies anything in `public/` into `dist/` automatically — create
   that folder if it doesn't exist yet.)
6. Deploy. Netlify will rebuild on every push to your main branch.

## 7. Telegram Mini App — not yet wired, here's the plan

This MVP is a normal web app. To turn it into the Telegram Mini App at
`https://t.me/sifonmabot/Sella9664` in a later phase:

1. Load `telegram-web-app.js` (already included in `index.html`) and call
   `window.Telegram.WebApp.ready()` / `.expand()` on mount.
2. Read `window.Telegram.WebApp.initData` and send it to a backend endpoint
   (a Supabase Edge Function is a good fit) that verifies the Telegram HMAC
   signature server-side, then either creates or signs in a matching
   Supabase user — never trust `initData` on the client alone.
3. Swap the navbar/layout for a mobile-first single-column shell when
   `window.Telegram?.WebApp` is present, and map Telegram's theme params
   (`themeParams.bg_color`, etc.) onto CSS variables instead of the fixed
   Tailwind palette.
4. Bot-side notifications (new answer, new reply, etc.) go through your
   Telegram bot backend calling the Bot API, triggered by Postgres changes
   (Supabase's `pg_net`/webhooks or an n8n workflow both work).

Don't claim this is done until it actually verifies `initData` server-side —
a purely client-side "detect Telegram" check is not real authentication.

## 8. Project structure

```
src/
  components/   Navbar, QuestionCard, VoteButton, FollowButton,
                CategoryChip, ProtectedRoute
  context/      AuthContext (Supabase session + profile)
  lib/          supabaseClient, reputation (badge thresholds)
  pages/        Home, Login, Signup, AskQuestion, QuestionDetail, Search,
                Categories, CategoryDetail, Profile, People, PublicProfile,
                Notifications
  types/        Shared TS types matching the DB schema
supabase/
  schema.sql    Phase 1 tables, triggers, RLS policies, seed categories
  phase2.sql    Phase 2: profile fields, follows, notifications, reputation
```

## Phase 2 notes

- **People discovery** (`/people`) lists members by reputation and supports
  searching by username, bio, profession, skill, or interest. A "you may
  want to connect with" section does a simple shared-interest overlap
  against your own profile — it's real data, not a placeholder, but it's
  intentionally a plain overlap query rather than an ML matching model
  (that's Phase 5).
- **Notifications** are written by Postgres trigger functions (`security
  definer`, so they can insert into another user's notifications row
  despite RLS) whenever someone answers your question, replies to your
  answer, or follows you. Visiting `/notifications` marks everything as
  read.
- **Reputation** is a stored integer on `profiles`, incremented/decremented
  by the same trigger pattern whenever a vote is cast, changed, or removed
  on your questions or answers. The two badge tiers in
  `src/lib/reputation.ts` are simple, honest thresholds on that number —
  swap in a richer badge system later without touching how reputation
  itself is computed.

## 9. Design notes

Palette: deep indigo (`#1B2A4A`) + gold accent (`#C89B3C`) on a warm paper
background (`#F7F5F1`), Fraunces for headings, Inter for UI text, IBM Plex
Mono for counts/tags — meant to read as a trustworthy knowledge/community
space rather than a generic SaaS landing page. Adjust `tailwind.config.js`
to retheme.

## 10. Roadmap (from the full product brief)

- **Phase 2** — profiles as discovery surfaces, people matching, following,
  notifications, reputation/badges.
- **Phase 3** — opportunities: business partner matching, education
  opportunities, jobs/projects/freelance.
- **Phase 4** — AI question moderation (approve/needs_edit/reject/human_review
  with confidence levels), AI-assisted search, summaries, translation.
- **Phase 5** — AI-driven people/opportunity matching, recommendations,
  analytics.

Each phase should extend this schema rather than replace it — e.g. Phase 4's
moderation pipeline writes into the existing `questions.status` column plus a
new `moderation_events` audit table, it doesn't change how questions are
already stored.
