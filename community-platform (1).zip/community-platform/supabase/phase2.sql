-- ============================================================
-- Commons — Phase 2 migration
-- Run this AFTER schema.sql, in the Supabase SQL editor.
-- Adds: richer profiles, following, notifications, reputation.
-- ============================================================

-- ---------- extend profiles for discovery/matching ----------
alter table public.profiles
  add column if not exists skills text[] not null default '{}',
  add column if not exists interests text[] not null default '{}',
  add column if not exists goals text,
  add column if not exists education text,
  add column if not exists profession text,
  add column if not exists languages text[] not null default '{}',
  add column if not exists location text,
  add column if not exists looking_for text,
  add column if not exists reputation integer not null default 0;

create index if not exists profiles_skills_idx on public.profiles using gin (skills);
create index if not exists profiles_interests_idx on public.profiles using gin (interests);

-- ---------- follows ----------
create table if not exists public.follows (
  follower_id uuid not null references auth.users(id) on delete cascade,
  followee_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, followee_id),
  check (follower_id <> followee_id)
);

create index if not exists follows_followee_idx on public.follows (followee_id);

-- ---------- notifications ----------
create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade, -- recipient
  type text not null check (
    type in ('new_answer', 'new_reply', 'new_follower', 'question_upvoted', 'answer_upvoted')
  ),
  -- References public.profiles (not auth.users) so PostgREST can auto-embed
  -- it as `actor:profiles!notifications_actor_id_fkey(*)`, same reasoning
  -- as author_id on questions/answers/replies in schema.sql.
  actor_id uuid references public.profiles(id) on delete set null,
  question_id uuid references public.questions(id) on delete cascade,
  answer_id uuid references public.answers(id) on delete cascade,
  message text not null,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on public.notifications (user_id, created_at desc);

alter table public.follows enable row level security;
alter table public.notifications enable row level security;

create policy "follow relationships are publicly readable" on public.follows
  for select using (true);
create policy "users can follow as themselves" on public.follows
  for insert with check (auth.uid() = follower_id);
create policy "users can unfollow as themselves" on public.follows
  for delete using (auth.uid() = follower_id);

create policy "users can read their own notifications" on public.notifications
  for select using (auth.uid() = user_id);
create policy "users can mark their own notifications read" on public.notifications
  for update using (auth.uid() = user_id);
-- No insert/delete policy for regular users: notifications are only ever
-- written by the SECURITY DEFINER trigger functions below, which bypass
-- RLS. This stops a user from writing fake notifications into someone
-- else's inbox.

-- ============================================================
-- Triggers: notifications + reputation
-- SECURITY DEFINER so e.g. answering someone else's question can insert
-- a notification row owned by that other user, despite RLS.
-- ============================================================

create or replace function public.notify_new_answer()
returns trigger language plpgsql security definer as $$
declare
  q_author uuid;
begin
  select author_id into q_author from public.questions where id = new.question_id;
  if q_author is not null and q_author <> new.author_id then
    insert into public.notifications (user_id, type, actor_id, question_id, answer_id, message)
    values (q_author, 'new_answer', new.author_id, new.question_id, new.id, 'Someone answered your question.');
  end if;
  return new;
end;
$$;

drop trigger if exists on_answer_notify on public.answers;
create trigger on_answer_notify
  after insert on public.answers
  for each row execute function public.notify_new_answer();

create or replace function public.notify_new_reply()
returns trigger language plpgsql security definer as $$
declare
  a_author uuid;
  q_id uuid;
begin
  select author_id, question_id into a_author, q_id from public.answers where id = new.answer_id;
  if a_author is not null and a_author <> new.author_id then
    insert into public.notifications (user_id, type, actor_id, question_id, answer_id, message)
    values (a_author, 'new_reply', new.author_id, q_id, new.answer_id, 'Someone replied to your answer.');
  end if;
  return new;
end;
$$;

drop trigger if exists on_reply_notify on public.replies;
create trigger on_reply_notify
  after insert on public.replies
  for each row execute function public.notify_new_reply();

create or replace function public.notify_new_follower()
returns trigger language plpgsql security definer as $$
begin
  insert into public.notifications (user_id, type, actor_id, message)
  values (new.followee_id, 'new_follower', new.follower_id, 'You have a new follower.');
  return new;
end;
$$;

drop trigger if exists on_follow_notify on public.follows;
create trigger on_follow_notify
  after insert on public.follows
  for each row execute function public.notify_new_follower();

-- Reputation: every upvote/downvote on a person's question or answer
-- adjusts their profiles.reputation by the same delta used for vote_count.
create or replace function public.handle_reputation_change()
returns trigger language plpgsql security definer as $$
declare
  target_id uuid;
  target_type text;
  delta integer;
  content_author uuid;
begin
  if tg_op = 'DELETE' then
    target_id := old.content_id; target_type := old.content_type; delta := -old.vote_type;
  elsif tg_op = 'INSERT' then
    target_id := new.content_id; target_type := new.content_type; delta := new.vote_type;
  else
    target_id := new.content_id; target_type := new.content_type; delta := new.vote_type - old.vote_type;
  end if;

  if target_type = 'question' then
    select author_id into content_author from public.questions where id = target_id;
  else
    select author_id into content_author from public.answers where id = target_id;
  end if;

  if content_author is not null then
    update public.profiles set reputation = reputation + delta where id = content_author;
  end if;

  return coalesce(new, old);
end;
$$;

drop trigger if exists on_vote_reputation on public.votes;
create trigger on_vote_reputation
  after insert or update or delete on public.votes
  for each row execute function public.handle_reputation_change();
