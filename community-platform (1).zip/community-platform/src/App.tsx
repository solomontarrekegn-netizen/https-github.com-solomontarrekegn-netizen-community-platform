import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import ProtectedRoute from './components/ProtectedRoute'
import Home from './pages/Home'
import Login from './pages/Login'
import Signup from './pages/Signup'
import AskQuestion from './pages/AskQuestion'
import QuestionDetail from './pages/QuestionDetail'
import Search from './pages/Search'
import Categories from './pages/Categories'
import CategoryDetail from './pages/CategoryDetail'
import Profile from './pages/Profile'
import People from './pages/People'
import PublicProfile from './pages/PublicProfile'
import Notifications from './pages/Notifications'

export default function App() {
  return (
    <div className="min-h-screen bg-paper">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/search" element={<Search />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/category/:slug" element={<CategoryDetail />} />
        <Route path="/question/:id" element={<QuestionDetail />} />
        <Route path="/people" element={<People />} />
        <Route path="/people/:username" element={<PublicProfile />} />
        <Route
          path="/notifications"
          element={
            <ProtectedRoute>
              <Notifications />
            </ProtectedRoute>
          }
        />
        <Route
          path="/ask"
          element={
            <ProtectedRoute>
              <AskQuestion />
            </ProtectedRoute>
          }
        />
        <Route
          path="/profile"
          element={
            <ProtectedRoute>
              <Profile />
            </ProtectedRoute>
          }
        />
        <Route path="*" element={<div className="p-8 text-center text-ink/50">Page not found.</div>} />
      </Routes>
    </div>
  )
}
