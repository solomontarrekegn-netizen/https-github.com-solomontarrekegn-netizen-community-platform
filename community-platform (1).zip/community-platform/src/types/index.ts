export type Profile = {
  id: string
  username: string
  display_name: string | null
  bio: string | null
  avatar_url: string | null
  created_at: string
  skills: string[]
  interests: string[]
  goals: string | null
  education: string | null
  profession: string | null
  languages: string[]
  location: string | null
  looking_for: string | null
  reputation: number
}

export type NotificationType =
  | 'new_answer'
  | 'new_reply'
  | 'new_follower'
  | 'question_upvoted'
  | 'answer_upvoted'

export type AppNotification = {
  id: string
  user_id: string
  type: NotificationType
  actor_id: string | null
  question_id: string | null
  answer_id: string | null
  message: string
  is_read: boolean
  created_at: string
  actor?: Profile | null
}

export type Category = {
  id: number
  name: string
  slug: string
  description: string | null
}

export type QuestionStatus = 'approved' | 'needs_edit' | 'rejected' | 'human_review'

export type Question = {
  id: string
  author_id: string
  title: string
  description: string
  category_id: number | null
  tags: string[]
  is_anonymous: boolean
  status: QuestionStatus
  answer_count: number
  vote_count: number
  created_at: string
  // Joined fields (populated client-side)
  author?: Profile | null
  category?: Category | null
}

export type Answer = {
  id: string
  question_id: string
  author_id: string
  body: string
  is_anonymous: boolean
  vote_count: number
  created_at: string
  author?: Profile | null
}

export type Reply = {
  id: string
  answer_id: string
  author_id: string
  body: string
  is_anonymous: boolean
  created_at: string
  author?: Profile | null
}
