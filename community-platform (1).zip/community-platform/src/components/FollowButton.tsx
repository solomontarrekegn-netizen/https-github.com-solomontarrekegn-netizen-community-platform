import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'

export default function FollowButton({ targetUserId }: { targetUserId: string }) {
  const { user } = useAuth()
  const [following, setFollowing] = useState(false)
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!user || user.id === targetUserId) return
    supabase
      .from('follows')
      .select('follower_id')
      .eq('follower_id', user.id)
      .eq('followee_id', targetUserId)
      .maybeSingle()
      .then(({ data }) => setFollowing(!!data))
  }, [user, targetUserId])

  if (!user || user.id === targetUserId) return null

  async function toggle() {
    if (!user || busy) return
    setBusy(true)
    if (following) {
      await supabase
        .from('follows')
        .delete()
        .eq('follower_id', user.id)
        .eq('followee_id', targetUserId)
      setFollowing(false)
    } else {
      await supabase.from('follows').insert({ follower_id: user.id, followee_id: targetUserId })
      setFollowing(true)
    }
    setBusy(false)
  }

  return (
    <button
      onClick={toggle}
      disabled={busy}
      className={`rounded-md px-4 py-1.5 text-sm font-medium disabled:opacity-50 ${
        following
          ? 'border border-line bg-white text-ink/70 hover:border-red-300 hover:text-red-600'
          : 'bg-indigo text-paper hover:bg-indigo-light'
      }`}
    >
      {following ? 'Following' : 'Follow'}
    </button>
  )
}
