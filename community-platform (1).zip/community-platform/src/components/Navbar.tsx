import { Link, useNavigate } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabaseClient'

export default function Navbar() {
  const { user, profile, signOut } = useAuth()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [unread, setUnread] = useState(0)

  useEffect(() => {
    if (!user) {
      setUnread(0)
      return
    }
    supabase
      .from('notifications')
      .select('id', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('is_read', false)
      .then(({ count }) => setUnread(count ?? 0))
  }, [user])

  function handleSearch(e: React.FormEvent) {
    e.preventDefault()
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`)
  }

  return (
    <header className="sticky top-0 z-10 border-b border-line bg-paper/95 backdrop-blur">
      <div className="mx-auto flex max-w-5xl items-center gap-4 px-4 py-3">
        <Link to="/" className="font-display text-xl font-semibold text-indigo shrink-0">
          Commons
        </Link>

        <form onSubmit={handleSearch} className="flex-1 max-w-md">
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions, people, topics"
            className="w-full rounded-md border border-line bg-white px-3 py-1.5 text-sm outline-none focus:border-indigo"
          />
        </form>

        <nav className="ml-auto hidden items-center gap-5 text-sm font-medium text-ink/80 sm:flex">
          <Link to="/" className="hover:text-indigo">
            Home
          </Link>
          <Link to="/people" className="hover:text-indigo">
            People
          </Link>
          <Link to="/categories" className="hover:text-indigo">
            Categories
          </Link>
          {user && (
            <Link to="/ask" className="rounded-md bg-indigo px-3 py-1.5 text-paper hover:bg-indigo-light">
              Ask
            </Link>
          )}
        </nav>

        {user ? (
          <div className="flex items-center gap-3">
            <Link to="/notifications" className="relative text-ink/70 hover:text-indigo" aria-label="Notifications">
              🔔
              {unread > 0 && (
                <span className="absolute -right-1.5 -top-1.5 rounded-full bg-gold px-1 text-[10px] font-medium text-white">
                  {unread}
                </span>
              )}
            </Link>
            <Link to="/profile" className="text-sm font-medium text-ink/80 hover:text-indigo">
              {profile?.username ?? 'Profile'}
            </Link>
            <button onClick={() => signOut()} className="text-sm text-ink/50 hover:text-ink">
              Sign out
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-3">
            <Link to="/login" className="text-sm font-medium hover:text-indigo">
              Log in
            </Link>
            <Link
              to="/signup"
              className="rounded-md bg-indigo px-3 py-1.5 text-sm font-medium text-paper hover:bg-indigo-light"
            >
              Join
            </Link>
          </div>
        )}
      </div>
    </header>
  )
}
