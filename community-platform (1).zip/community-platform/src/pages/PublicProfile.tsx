import { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { Profile } from '../types'
import FollowButton from '../components/FollowButton'
import { reputationBadge } from '../lib/reputation'

function Field({ label, value }: { label: string; value: string | string[] | null }) {
  if (!value || (Array.isArray(value) && value.length === 0)) return null
  return (
    <div>
      <div className="text-xs font-medium uppercase tracking-wide text-ink/40">{label}</div>
      <div className="mt-0.5 text-sm text-ink/80">
        {Array.isArray(value) ? value.join(', ') : value}
      </div>
    </div>
  )
}

export default function PublicProfile() {
  const { username } = useParams()
  const [person, setPerson] = useState<Profile | null>(null)
  const [followerCount, setFollowerCount] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!username) return

    async function load() {
      const { data } = await supabase.from('profiles').select('*').eq('username', username).single()
      setPerson(data as Profile)

      if (data) {
        const { count } = await supabase
          .from('follows')
          .select('follower_id', { count: 'exact', head: true })
          .eq('followee_id', (data as Profile).id)
        setFollowerCount(count ?? 0)
      }
      setLoading(false)
    }

    load()
  }, [username])

  if (loading) return <div className="p-8 text-center text-ink/50">Loading…</div>
  if (!person) return <div className="p-8 text-center text-ink/50">Person not found.</div>

  const badge = reputationBadge(person.reputation)

  return (
    <div className="mx-auto max-w-2xl px-4 py-10">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-display text-2xl font-semibold text-indigo">
              {person.display_name || person.username}
            </h1>
            {badge && (
              <span className={`rounded-sm px-2 py-0.5 text-xs font-medium ${badge.className}`}>
                {badge.label}
              </span>
            )}
          </div>
          <p className="text-sm text-ink/50">
            @{person.username} · {followerCount} followers · {person.reputation} reputation
          </p>
        </div>
        <FollowButton targetUserId={person.id} />
      </div>

      {person.bio && <p className="mt-4 text-ink/80">{person.bio}</p>}

      <div className="mt-6 grid grid-cols-2 gap-4">
        <Field label="Profession" value={person.profession} />
        <Field label="Location" value={person.location} />
        <Field label="Education" value={person.education} />
        <Field label="Languages" value={person.languages} />
        <Field label="Skills" value={person.skills} />
        <Field label="Interests" value={person.interests} />
        <Field label="Goals" value={person.goals} />
        <Field label="Looking for" value={person.looking_for} />
      </div>
    </div>
  )
}
