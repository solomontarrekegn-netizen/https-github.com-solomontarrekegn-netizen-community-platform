import { useEffect, useState, FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import { Profile } from '../types'
import FollowButton from '../components/FollowButton'
import { reputationBadge } from '../lib/reputation'

export default function People() {
  const { user, profile } = useAuth()
  const [people, setPeople] = useState<Profile[]>([])
  const [query, setQuery] = useState('')
  const [loading, setLoading] = useState(true)
  const [recommended, setRecommended] = useState<Profile[]>([])

  async function load(searchTerm = '') {
    setLoading(true)
    let req = supabase.from('profiles').select('*').order('reputation', { ascending: false }).limit(30)

    if (searchTerm.trim()) {
      const term = searchTerm.trim()
      req = req.or(
        `username.ilike.%${term}%,bio.ilike.%${term}%,profession.ilike.%${term}%,skills.cs.{${term}},interests.cs.{${term}}`
      )
    }
    if (user) req = req.neq('id', user.id)

    const { data } = await req
    setPeople((data as Profile[]) ?? [])
    setLoading(false)
  }

  useEffect(() => {
    load()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user])

  // "People you may want to connect with" — a simple overlap on shared
  // interests with the current user's profile, not an ML matching model.
  useEffect(() => {
    if (!profile || !user || profile.interests.length === 0) {
      setRecommended([])
      return
    }
    supabase
      .from('profiles')
      .select('*')
      .neq('id', user.id)
      .overlaps('interests', profile.interests)
      .limit(6)
      .then(({ data }) => setRecommended((data as Profile[]) ?? []))
  }, [profile, user])

  function handleSearch(e: FormEvent) {
    e.preventDefault()
    load(query)
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8">
      <h1 className="mb-2 font-display text-2xl font-semibold text-indigo">People</h1>
      <p className="mb-6 text-sm text-ink/60">
        Find people by skill, interest, or profession.
      </p>

      <form onSubmit={handleSearch} className="mb-6 flex gap-2">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="e.g. AI, agriculture, startups"
          className="flex-1 rounded-md border border-line bg-white px-3 py-2 text-sm outline-none focus:border-indigo"
        />
        <button className="rounded-md bg-indigo px-4 py-2 text-sm font-medium text-paper hover:bg-indigo-light">
          Search
        </button>
      </form>

      {recommended.length > 0 && (
        <div className="mb-8">
          <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ink/50">
            You may want to connect with
          </h2>
          <div className="flex flex-col gap-3">
            {recommended.map((p) => (
              <PersonRow key={p.id} person={p} />
            ))}
          </div>
        </div>
      )}

      <h2 className="mb-3 font-display text-sm font-semibold uppercase tracking-wide text-ink/50">
        {query ? 'Results' : 'All members'}
      </h2>

      {loading && <p className="text-ink/50">Loading…</p>}
      {!loading && people.length === 0 && <p className="text-ink/50">No one matched that search.</p>}

      <div className="flex flex-col gap-3">
        {people.map((p) => (
          <PersonRow key={p.id} person={p} />
        ))}
      </div>
    </div>
  )
}

function PersonRow({ person }: { person: Profile }) {
  const badge = reputationBadge(person.reputation)
  return (
    <div className="flex items-center justify-between rounded-md border border-line bg-white p-4">
      <Link to={`/people/${person.username}`} className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-display font-semibold text-ink">
            {person.display_name || person.username}
          </span>
          {badge && (
            <span className={`rounded-sm px-1.5 py-0.5 text-[10px] font-medium ${badge.className}`}>
              {badge.label}
            </span>
          )}
        </div>
        {person.profession && <div className="text-xs text-ink/50">{person.profession}</div>}
        {person.bio && <p className="mt-1 line-clamp-1 text-sm text-ink/70">{person.bio}</p>}
        {person.interests.length > 0 && (
          <div className="mt-1 flex flex-wrap gap-1">
            {person.interests.slice(0, 4).map((i) => (
              <span key={i} className="font-mono text-xs text-gold-dark">
                #{i}
              </span>
            ))}
          </div>
        )}
      </Link>
      <FollowButton targetUserId={person.id} />
    </div>
  )
}
