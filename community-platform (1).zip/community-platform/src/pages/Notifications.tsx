import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import { AppNotification } from '../types'

function targetLink(n: AppNotification): string | null {
  if (n.type === 'new_follower') return n.actor ? `/people/${n.actor.username}` : null
  if (n.question_id) return `/question/${n.question_id}`
  return null
}

export default function Notifications() {
  const { user } = useAuth()
  const [items, setItems] = useState<AppNotification[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) return

    async function load() {
      const { data } = await supabase
        .from('notifications')
        .select('*, actor:profiles!notifications_actor_id_fkey(*)')
        .eq('user_id', user!.id)
        .order('created_at', { ascending: false })
        .limit(50)

      setItems((data as AppNotification[]) ?? [])
      setLoading(false)

      const unreadIds = ((data as AppNotification[]) ?? []).filter((n) => !n.is_read).map((n) => n.id)
      if (unreadIds.length > 0) {
        await supabase.from('notifications').update({ is_read: true }).in('id', unreadIds)
      }
    }

    load()
  }, [user])

  if (!user) return null

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 font-display text-2xl font-semibold text-indigo">Notifications</h1>

      {loading && <p className="text-ink/50">Loading…</p>}
      {!loading && items.length === 0 && (
        <p className="text-ink/50">Nothing yet — activity on your questions and answers will show up here.</p>
      )}

      <div className="flex flex-col gap-2">
        {items.map((n) => {
          const link = targetLink(n)
          const content = (
            <div
              className={`rounded-md border p-3 text-sm ${
                n.is_read ? 'border-line bg-white' : 'border-gold/50 bg-gold/5'
              }`}
            >
              <span className="font-medium text-ink">
                {n.actor?.display_name || n.actor?.username || 'Someone'}
              </span>{' '}
              <span className="text-ink/70">{n.message.replace(/^Someone /, '')}</span>
              <div className="mt-1 text-xs text-ink/40">
                {new Date(n.created_at).toLocaleString()}
              </div>
            </div>
          )
          return link ? (
            <Link key={n.id} to={link}>
              {content}
            </Link>
          ) : (
            <div key={n.id}>{content}</div>
          )
        })}
      </div>
    </div>
  )
}
