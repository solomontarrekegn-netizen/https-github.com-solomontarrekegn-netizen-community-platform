import { useState, FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { useAuth } from '../context/AuthContext'
import { reputationBadge } from '../lib/reputation'

function listToText(list: string[]) {
  return list.join(', ')
}
function textToList(text: string): string[] {
  return text
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
}

export default function Profile() {
  const { profile, refreshProfile } = useAuth()
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '')
  const [bio, setBio] = useState(profile?.bio ?? '')
  const [profession, setProfession] = useState(profile?.profession ?? '')
  const [location, setLocation] = useState(profile?.location ?? '')
  const [education, setEducation] = useState(profile?.education ?? '')
  const [goals, setGoals] = useState(profile?.goals ?? '')
  const [lookingFor, setLookingFor] = useState(profile?.looking_for ?? '')
  const [skills, setSkills] = useState(listToText(profile?.skills ?? []))
  const [interests, setInterests] = useState(listToText(profile?.interests ?? []))
  const [languages, setLanguages] = useState(listToText(profile?.languages ?? []))
  const [busy, setBusy] = useState(false)
  const [saved, setSaved] = useState(false)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!profile) return
    setBusy(true)
    setSaved(false)
    await supabase
      .from('profiles')
      .update({
        display_name: displayName,
        bio,
        profession,
        location,
        education,
        goals,
        looking_for: lookingFor,
        skills: textToList(skills),
        interests: textToList(interests),
        languages: textToList(languages),
      })
      .eq('id', profile.id)
    await refreshProfile()
    setBusy(false)
    setSaved(true)
  }

  if (!profile) return <div className="p-8 text-center text-ink/50">Loading…</div>

  const badge = reputationBadge(profile.reputation)

  return (
    <div className="mx-auto max-w-lg px-4 py-10">
      <div className="mb-1 flex items-center gap-2">
        <h1 className="font-display text-2xl font-semibold text-indigo">@{profile.username}</h1>
        {badge && (
          <span className={`rounded-sm px-2 py-0.5 text-xs font-medium ${badge.className}`}>
            {badge.label}
          </span>
        )}
      </div>
      <p className="mb-6 text-sm text-ink/50">
        {profile.reputation} reputation ·{' '}
        <Link to={`/people/${profile.username}`} className="text-indigo hover:underline">
          View public profile
        </Link>
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <label className="text-sm font-medium">
          Display name
          <input
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>
        <label className="text-sm font-medium">
          Bio
          <textarea
            rows={3}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <div className="grid grid-cols-2 gap-4">
          <label className="text-sm font-medium">
            Profession
            <input
              value={profession}
              onChange={(e) => setProfession(e.target.value)}
              className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
            />
          </label>
          <label className="text-sm font-medium">
            Location
            <input
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
            />
          </label>
        </div>

        <label className="text-sm font-medium">
          Education
          <input
            value={education}
            onChange={(e) => setEducation(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          Skills (comma separated)
          <input
            value={skills}
            onChange={(e) => setSkills(e.target.value)}
            placeholder="React, product design, agronomy"
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          Interests (comma separated)
          <input
            value={interests}
            onChange={(e) => setInterests(e.target.value)}
            placeholder="AI, startups, education"
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          Languages (comma separated)
          <input
            value={languages}
            onChange={(e) => setLanguages(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          Goals
          <textarea
            rows={2}
            value={goals}
            onChange={(e) => setGoals(e.target.value)}
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <label className="text-sm font-medium">
          What I'm looking for
          <input
            value={lookingFor}
            onChange={(e) => setLookingFor(e.target.value)}
            placeholder="A mentor, a co-founder, study partners…"
            className="mt-1 w-full rounded-md border border-line bg-white px-3 py-2 outline-none focus:border-indigo"
          />
        </label>

        <button
          disabled={busy}
          className="self-start rounded-md bg-indigo px-5 py-2 font-medium text-paper hover:bg-indigo-light disabled:opacity-50"
        >
          {busy ? 'Saving…' : 'Save profile'}
        </button>
        {saved && <p className="text-sm text-sage">Saved.</p>}
      </form>
    </div>
  )
}
