// Simple, transparent thresholds for Phase 2. The product brief's fuller
// badge system (moderator recognition, verified professional, etc.) needs
// data this MVP doesn't track yet, so this only derives from `reputation`,
// which is a real, stored, vote-driven number — not decorative.
export function reputationBadge(reputation: number): { label: string; className: string } | null {
  if (reputation >= 100) return { label: 'Top Answerer', className: 'bg-gold text-white' }
  if (reputation >= 25) return { label: 'Helpful Contributor', className: 'bg-sage text-white' }
  return null
}
